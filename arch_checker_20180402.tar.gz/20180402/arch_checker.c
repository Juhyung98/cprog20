#include<stdio.h>

void is_64bit_machine()
{
	long num = 123;
	int size_num = sizeof(num);

	if (size_num == 8)
		printf("Your Machine is running on 64 bit OS\n");
	else
		printf("Your Machine is running on 32 bit OS\n");
}

void is_little_endian()
{
	int num = 0x01234567;
	
	if ( *((char*)&num) == 0x67)
		printf("Your Machine uses Little Endian way to store values\n");
	else
		printf("Your Machine uses Big Endian way to store values\n");
}



int main()
{
	is_64bit_machine();
	is_little_endian();

	return 0;
}
